﻿namespace BeanSceneReservationApplication.Data
{
    public class SittingType
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
